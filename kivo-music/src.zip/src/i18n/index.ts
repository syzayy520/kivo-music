// src/i18n/index.ts
export { I18nProvider, useI18n } from "./I18nProvider";
export type { SupportedLocale } from "./I18nProvider";
